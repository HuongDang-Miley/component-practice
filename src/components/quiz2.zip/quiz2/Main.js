import React, { Component } from 'react'
import './style.css'
import ShowData from './ShowData.js'
export default class Main extends Component {
    constructor(props) {
        super(props)
        this.state = {
            tempExercise: '',
            tempCal: '',
            data: [
                {
                    exercise: 'squat',
                    cal: 140,
                },
                {
                    exercise: 'hiit',
                    cal: 100,
                },
            ]
        }
    }

    handleExerciseChange = (e) => {
        this.setState({
            ...this.state,
            tempExercise: e.target.value
        })
    }


    handleCalChange = (e) => {
        this.setState({
            ...this.state,
            tempCal: e.target.value
        })
    }

    handleSubmitBtn = () => {
        // Copy current array of exercise and calory, then push new object into it
        let newArray = [
            ...this.state.data,
            {
                exercise: this.state.tempExercise,
                cal: this.state.tempCal
            }]

        // Update the State
        this.setState({
            ...this.state,
            data: newArray,
        })
        // Clear input field after submit
        document.getElementById('exerciseInput').value = ''
        document.getElementById('calInput').value = ''
    }


    render() {
        return (
            <div class='classComponent'>
                <h1>Exercise App Quiz 2</h1>
                <div>
                    <label>Exercise</label>
                    <input id='exerciseInput' onChange={this.handleExerciseChange}></input>
                    <label>Calories</label>
                    <input id='calInput' onChange={this.handleCalChange}></input>
                    <button onClick={this.handleSubmitBtn}>Submit</button>
                </div>
                {this.state.data.map(item => {
                    return (
                        <ShowData exercise={item.exercise} cal={item.cal} />
                    )
                })}
            </div>
        )
    }
}
